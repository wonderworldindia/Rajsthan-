# Universal Learning Engine Prototype V1.0 — QA Report

**Date:** 2026-11-27  
**Environment:** Isolated local workspace; Node.js 22.16.0; Chromium 144 available but headless execution did not complete.  
**Scope:** Prototype source only. No existing HTML, GitHub repository, Firebase project, Cloudflare Worker, or live website was modified.

## 1. Test summary

| Test Area | Result | Evidence |
|---|---|---|
| Core unit tests | PASS — 24/24 | `unit-test-output.txt` |
| JavaScript syntax checks | PASS — all `src/*.js` files | `syntax-check-result.txt` |
| Local HTTP static smoke | PASS | `http-smoke-result.txt` |
| Question bank schema | PASS — 10 bilingual records, unique IDs, valid answer references | Unit tests |
| Shuffle + answer mapping | PASS | Unit tests verify stable option IDs after shuffle |
| Language resolution | PASS — English, Hindi, Both, missing translation flag | Unit tests |
| Voice controller | PASS with mocked speech engine | Unit tests |
| Bilingual speech queue | PASS with mocked speech engine | Unit tests |
| Revision interval calculation | PASS | Unit tests |
| IndexedDB unavailable path | PASS — explicit error, no false success | Unit tests |
| Real browser UI execution | BLOCKED / NOT VERIFIED | Chromium headless `dump-dom` process timed out; no DOM output |
| Real IndexedDB persistence in browser | NOT VERIFIED | Requires functioning browser runtime |
| Real Android Hindi/English TTS | NOT VERIFIED | Requires target Android device/browser and installed voices |
| Offline reload/resume end-to-end | NOT VERIFIED | Requires browser IndexedDB runtime test |

## 2. What passed

- Fisher–Yates shuffle preserves item set and does not mutate source array.
- Invalid random source values are rejected.
- Scoring uses stable option IDs, not option positions.
- Unknown option IDs are rejected.
- Accuracy handles zero attempts and invalid counts.
- Language resolver supports `en`, `hi`, `both`, and flags missing translations.
- Quiz selection rejects insufficient pools and duplicate question IDs.
- Shuffled option order does not break answer mapping.
- Ten sample questions have unique IDs, bilingual prompts/explanations, and answer keys that reference real option IDs.
- Revision policy interval calculations match the configured prototype policy.
- Voice controller selects matching language voices, handles unavailable voice, validates preferences, stops current speech, sequences English then Hindi, and clears queued segments on stop — all under a mocked speech engine.
- Static HTTP server returns the HTML, JS modules, and test source files.

## 3. Browser test failure / limitation

Chromium 144 was present, but repeated headless invocations with `--dump-dom` did not terminate within the timeout and produced an empty DOM capture. The captured stderr contains container D-Bus/zygote environment errors. This is an environment/tooling failure, not evidence that the app UI passed or failed. Browser behavior remains unverified.

## 4. Known limitations before integration

1. Real browser runtime, IndexedDB persistence, reload, and resume must be verified on Android Chrome and at least one desktop browser.
2. TTS must be tested on the target Android device for Hindi voice availability, pronunciation, queue cancellation, pause/resume, and rapid repeated taps.
3. Resume logic is implemented against the saved local session snapshot, but requires real-browser end-to-end validation.
4. Practice and Learning modes currently differ only in explanation visibility; a full policy specification is still required before any formal assessment mode is introduced.
5. No Firebase Auth, Firestore Security Rules, Cloudflare Worker, server-authoritative scoring, class roles, production backup, or multi-device sync is included.
6. The sample question bank is synthetic demonstration content and must not be treated as an approved school/exam question bank.

## 5. Decision

**NOT APPROVED FOR INTEGRATION.** The automated unit and static-server checks pass, but browser runtime, actual IndexedDB, and target-device voice tests remain open. The next gate is manual browser testing on the user's Android device (or a working browser automation environment), followed by a second QA report. Only after all critical tests pass should an integration proposal be prepared. No integration or deployment is authorized by this report.
