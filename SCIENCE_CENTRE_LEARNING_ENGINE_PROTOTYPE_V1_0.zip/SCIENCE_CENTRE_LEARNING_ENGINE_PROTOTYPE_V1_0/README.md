# SCIENCE CENTRE LEARNING HUB — Universal Learning Engine Prototype V1.0

Standalone prototype created in a new isolated folder. It does not connect to Firebase, Cloudflare, GitHub, existing Quiz Apps, or any production website.

## Included
- Hindi / English / Both content display
- Random question session and stable option-ID scoring
- Browser Speech Synthesis controller, including sequential English + Hindi speech and text fallback
- IndexedDB local attempt/session snapshot and revision-event persistence
- Attempt resume from locally saved session metadata and answers
- Accuracy and revision interval algorithms
- Node automated unit tests, module syntax checks, and static HTTP smoke checks

## Run locally
```bash
npm test
./tests/browser-smoke.sh
npm run serve
```
Open `http://localhost:8765`.

## Known limitations
- This is a local prototype with eight synthetic sample Science questions, not a verified question bank.
- No real Firebase authentication, server-authoritative scoring, Cloudflare API, role authorization, or multi-device sync.
- IndexedDB data is local demo data; it is not production-grade data protection.
- Browser TTS voice availability and pronunciation quality depend on the device/browser.
- Browser UI automation could not be completed in the current container because headless Chromium did not terminate/respond to dump-dom; see QA report. Manual Android Chrome testing is still required.
- Practice and Learning selector is present, but the two modes do not yet have distinct feedback policies.
